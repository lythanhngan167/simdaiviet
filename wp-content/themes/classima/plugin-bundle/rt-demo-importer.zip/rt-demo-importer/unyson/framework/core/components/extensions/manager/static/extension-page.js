jQuery(function($){
	$('#fw-extension-docs a:fw-external').attr('target', '_blank');
});